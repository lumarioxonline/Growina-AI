import cron from "node-cron";
import { prisma } from "../app/db.server.js";
import { computeAndStoreDailyReport } from "../app/models/reports.server.js";
import { sendEmail } from "../app/lib/email.server.js";
import { notifyWebhooks } from "../app/lib/webhook-notify.server.js";

function isoDate(d: Date) {
  return d.toISOString().slice(0, 10);
}

async function evaluateAlerts(shopDomain: string, dayISO: string) {
  const shop = await prisma.shop.findUnique({ where: { shopDomain } });
  if (!shop) return;

  const rules = await prisma.alertRule.findMany({ where: { shopId: shop.id, isActive: true } });
  if (rules.length === 0) return;

  const dayStart = new Date(dayISO + "T00:00:00.000Z");
  const dayEnd = new Date(dayStart.getTime() + 24 * 60 * 60 * 1000);

  const orders = await prisma.order.findMany({
    where: { shopId: shop.id, createdAt: { gte: dayStart, lt: dayEnd } },
    select: { revenue: true, profit: true, shippingCost: true },
  });

  const revenue = orders.reduce((a, o) => a + o.revenue, 0);
  const profit = orders.reduce((a, o) => a + o.profit, 0);
  const marginPct = revenue > 0 ? (profit / revenue) * 100 : 0;
  const avgShip = orders.length ? orders.reduce((a,o)=>a+o.shippingCost,0) / orders.length : 0;

  const events: Array<{ type: string; message: string }> = [];
  for (const r of rules) {
    if (r.type === "PROFIT_BELOW" && r.threshold != null && profit < r.threshold) {
      events.push({ type: r.type, message: `Winst onder drempel: ${profit.toFixed(2)} < ${r.threshold}` });
    }
    if (r.type === "MARGIN_BELOW" && r.threshold != null && marginPct < r.threshold) {
      events.push({ type: r.type, message: `Marge onder drempel: ${marginPct.toFixed(1)}% < ${r.threshold}%` });
    }
    if (r.type === "SHIPPING_ABOVE" && r.threshold != null && avgShip > r.threshold) {
      events.push({ type: r.type, message: `Shipping cost boven drempel: ${avgShip.toFixed(2)} > ${r.threshold}` });
    }
  }

  if (events.length === 0) return;

  for (const ev of events) {
    await prisma.alertEvent.create({ data: { shopId: shop.id, type: ev.type, message: ev.message } });
  }

  await notifyWebhooks(shop.id, "alerts", { day: dayISO, events, revenue, profit, marginPct, avgShip });

  const smtpOk = !!(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS);
  const to = process.env.REPORT_TO_EMAIL || "";
  if (!smtpOk || !to) return;

  const html = `
    <h2>Growina alerts (${dayISO})</h2>
    <p><b>Shop:</b> ${shop.shopDomain}</p>
    <ul>
      ${events.map(e => `<li><b>${e.type}</b> — ${e.message}</li>`).join("")}
    </ul>
    <p>Revenue: ${revenue.toFixed(2)} ${shop.currency} • Profit: ${profit.toFixed(2)} ${shop.currency} • Margin: ${marginPct.toFixed(1)}%</p>
  `;

  await sendEmail({ to, subject: `Growina alerts ${dayISO}`, html });
}

async function runDaily() {
  const shops = await prisma.shop.findMany({ select: { shopDomain: true } });

  const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const day = isoDate(yesterday);

  for (const s of shops) {
    try {
      const { shop, report, adSpend, profitBeforeAds } = await computeAndStoreDailyReport(s.shopDomain, day);

      await notifyWebhooks(shop.id, "daily_report", {
        day,
        revenue: report.revenue,
        profitBeforeAds,
        adSpend,
        profit: report.profit,
        marginPct: report.marginPct,
        currency: shop.currency,
      });

      await evaluateAlerts(s.shopDomain, day);

      const smtpOk = !!(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS);
      const to = process.env.REPORT_TO_EMAIL || "";
      if (!smtpOk || !to) continue;

      const html = `
        <h2>Growina daily report (${day})</h2>
        <p><b>Shop:</b> ${shop.shopDomain}</p>
        <p><b>Revenue:</b> ${report.revenue.toFixed(2)} ${shop.currency}</p>
        <p><b>Profit (before ads):</b> ${profitBeforeAds.toFixed(2)} ${shop.currency}</p>
        <p><b>Ad spend:</b> ${adSpend.toFixed(2)} ${shop.currency}</p>
        <p><b>Net profit:</b> ${report.profit.toFixed(2)} ${shop.currency}</p>
        <p><b>Margin:</b> ${report.marginPct.toFixed(1)}%</p>
      `;

      await sendEmail({ to, subject: `Growina report ${day}`, html });
    } catch (e) {
      console.error("Daily worker failed for shop", s.shopDomain, e);
    }
  }
}

async function main() {
  console.log("Growina worker started");
  await runDaily();

  cron.schedule("0 7 * * *", () => {
    runDaily().catch(console.error);
  });
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
