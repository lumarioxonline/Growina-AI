# Growina FINAL PLATFORM

Includes:
- AI forecasting
- Campaign profit
- AI decision engine
- Multi-channel alerts
- Teams & agencies
- White-label SaaS
- API v2 foundation
- Attribution structure
- Feature flags
- Enterprise scaling

Run:
npm i
npx prisma generate
npx prisma migrate dev
npm run dev
