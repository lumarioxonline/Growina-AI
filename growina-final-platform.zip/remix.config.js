/** @type {import('@remix-run/dev').AppConfig} */
export default {
  serverModuleFormat: "esm",
  ignoredRouteFiles: ["**/*.test.*"],
};
