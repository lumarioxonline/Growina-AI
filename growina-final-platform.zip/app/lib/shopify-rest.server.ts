import type { Session } from "@prisma/client";

const API_VERSION = process.env.SHOPIFY_API_VERSION || "2025-07";

export async function shopifyRest(session: Pick<Session, "shop" | "accessToken">, path: string) {
  const url = `https://${session.shop}/admin/api/${API_VERSION}${path.startsWith("/") ? path : "/" + path}`;
  const res = await fetch(url, {
    headers: {
      "X-Shopify-Access-Token": session.accessToken,
      "Content-Type": "application/json",
    },
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Shopify REST error ${res.status}: ${text}`);
  }
  return res.json();
}
