import { redirect } from "@remix-run/node";
import { authenticate } from "~/shopify.server";
import { prisma } from "~/db.server";

export type PlanKey = "STARTER" | "GROWTH" | "PRO";

export async function requireActivePlan(request: Request, allowed: PlanKey[] = ["STARTER","GROWTH","PRO"]) {
  const { billing, session } = await authenticate.admin(request);

  // If you prefer Managed App Pricing, set BYPASS_BILLING=true in env.
  if (process.env.BYPASS_BILLING === "true") return { session };

  await billing.require({
    plans: allowed,
    onFailure: async () => {
      throw redirect("/app/billing");
    },
  });

  // Store plan in DB (best-effort)
  try {
    const check = await billing.check({ plans: allowed });
    const active = check.hasActivePayment ? "paid" : "free";
    await prisma.shop.update({
      where: { shopDomain: session.shop },
      data: { plan: active },
    });
  } catch {}

  return { session };
}

export async function requestPlan(request: Request, plan: PlanKey) {
  const { billing } = await authenticate.admin(request);
  return billing.request({
    plan,
    isTest: process.env.BILLING_TEST === "true",
    returnUrl: "/app",
  });
}
