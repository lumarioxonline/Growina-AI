import { prisma } from "~/db.server";
import { shopifyRest } from "~/lib/shopify-rest.server";
import { computeProfit } from "~/lib/profit.server";

/**
 * Backfill last N days of orders (status=any), then upsert orders + items.
 * This uses REST orders.json for simplicity.
 */
export async function backfillOrders(params: { shopDomain: string; accessToken: string; days: number }) {
  const shop = await prisma.shop.findUnique({ where: { shopDomain: params.shopDomain } });
  if (!shop) throw new Error("Shop not found");

  const since = new Date(Date.now() - params.days * 24 * 60 * 60 * 1000);
  const createdAtMin = since.toISOString();

  let pageInfo: string | null = null;
  let total = 0;

  while (true) {
    const query = new URLSearchParams({
      status: "any",
      limit: "250",
      created_at_min: createdAtMin,
      ...(pageInfo ? { page_info: pageInfo } : {}),
    });

    // NOTE: Shopify pagination uses Link headers; REST page_info is returned via headers, not body.
    // For MVP we fetch first page only to avoid complex pagination without access to headers in helper.
    const data = await shopifyRest({ shop: params.shopDomain, accessToken: params.accessToken } as any, `/orders.json?${query.toString()}`);
    const orders = data.orders ?? [];

    for (const o of orders) {
      await upsertOrderFromPayload(shop.id, params.shopDomain, o);
      total++;
    }

    break; // first page only
  }

  return { total, since: createdAtMin };
}

async function upsertOrderFromPayload(shopId: string, shopDomain: string, payload: any) {
  const shopRow = await prisma.shop.findUnique({ where: { shopDomain } });
  if (!shopRow) return;

  const shopifyOrderId = String(payload.id);
  const currency = String(payload.currency ?? shopRow.currency ?? "EUR");

  const createdAt = payload.created_at ? new Date(payload.created_at) : new Date();
  const processedAt = payload.processed_at ? new Date(payload.processed_at) : null;

  const subtotal = Number(payload.current_subtotal_price ?? payload.subtotal_price ?? 0);
  const shippingRevenue = Number(payload.total_shipping_price_set?.shop_money?.amount ?? payload.total_shipping_price ?? 0);
  const discounts = Number(payload.total_discounts ?? 0);
  const taxes = Number(payload.total_tax ?? 0);

  let cogsTotal = 0;
  const itemsData: any[] = [];

  for (const li of payload.line_items ?? []) {
    const shopifyProductId = String(li.product_id ?? "");
    const shopifyVariantId = String(li.variant_id ?? "");
    const sku = li.sku ? String(li.sku) : null;
    const productTitle = li.title ? String(li.title) : "Product";
    const variantTitle = li.variant_title ? String(li.variant_title) : null;

    const product = await prisma.product.upsert({
      where: { shopId_shopifyProductId: { shopId, shopifyProductId } },
      update: { title: productTitle },
      create: { shopId, shopifyProductId, title: productTitle },
    });

    const variant = shopifyVariantId
      ? await prisma.variant.upsert({
          where: { shopId_shopifyVariantId: { shopId, shopifyVariantId } },
          update: { sku, title: variantTitle, productId: product.id },
          create: { shopId, productId: product.id, shopifyVariantId, sku, title: variantTitle },
        })
      : null;

    const qty = Number(li.quantity ?? 0);
    const price = Number(li.price ?? 0);

    const unitCost = variant?.cost ?? 0;
    const cogs = unitCost * qty;
    cogsTotal += cogs;

    itemsData.push({
      shopId,
      shopifyLineItemId: String(li.id),
      quantity: qty,
      price,
      cogs,
      variantId: variant?.id ?? null,
    });
  }

  const shippingCost = shopRow.avgShippingCost ?? 0;
  const returnCost = 0;

  const { revenue, fees, profit, marginPct } = computeProfit({
    subtotal,
    shippingRevenue,
    discounts,
    taxes,
    refundedSubtotal: 0,
    refundedShipping: 0,
    refundedTaxes: 0,
    cogs: cogsTotal,
    paymentFeePct: shopRow.paymentFeePct ?? 0,
    paymentFeeFixed: shopRow.paymentFeeFixed ?? 0,
    shippingCost,
    returnCost,
  });

  const order = await prisma.order.upsert({
    where: { shopId_shopifyOrderId: { shopId, shopifyOrderId } },
    update: {
      createdAt,
      processedAt: processedAt ?? undefined,
      currency,
      subtotal,
      shippingRevenue,
      discounts,
      taxes,
      cogs: cogsTotal,
      fees,
      shippingCost,
      returnCost,
      revenue,
      profit,
      marginPct,
    },
    create: {
      shopId,
      shopifyOrderId,
      createdAt,
      processedAt: processedAt ?? undefined,
      currency,
      subtotal,
      shippingRevenue,
      discounts,
      taxes,
      cogs: cogsTotal,
      fees,
      shippingCost,
      returnCost,
      revenue,
      profit,
      marginPct,
    },
  });

  await prisma.orderItem.deleteMany({ where: { orderId: order.id } });
  if (itemsData.length) {
    await prisma.orderItem.createMany({ data: itemsData.map((d) => ({ ...d, orderId: order.id })) });
  }
}
