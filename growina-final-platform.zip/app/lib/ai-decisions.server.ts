import { prisma } from "~/db.server";

export async function generateDecisions(shopId: string) {
  const campaigns = await prisma.campaignMetric.findMany({
    where: { shopId },
    orderBy: { date: "desc" },
    take: 30,
  });

  const decisions: string[] = [];

  for (const c of campaigns) {
    if (c.spend > 0 && c.profit < 0) {
      decisions.push(`Stop campaign ${c.campaign}`);
    }
    if (c.revenue > 0 && c.profit / c.revenue > 0.3) {
      decisions.push(`Scale campaign ${c.campaign}`);
    }
  }

  return decisions;
}
