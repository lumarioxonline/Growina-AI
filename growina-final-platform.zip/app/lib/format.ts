export function formatMoney(value: number, currency = "EUR") {
  try {
    return new Intl.NumberFormat(undefined, { style: "currency", currency }).format(value);
  } catch {
    return `${value.toFixed(2)} ${currency}`;
  }
}
export function formatPct(value: number) {
  return `${value.toFixed(1)}%`;
}
