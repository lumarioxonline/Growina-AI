import { prisma } from "~/db.server";
import * as stats from "simple-statistics";

export async function generateForecast(shopId: string) {
  const reports = await prisma.dailyReport.findMany({
    where: { shopId },
    orderBy: { date: "asc" },
    take: 90,
  });

  if (reports.length < 7) return null;

  const revenueSeries = reports.map(r => r.revenue);
  const profitSeries = reports.map(r => r.profit);

  const revenueTrend = stats.linearRegression(
    revenueSeries.map((v,i)=>[i,v])
  );

  const profitTrend = stats.linearRegression(
    profitSeries.map((v,i)=>[i,v])
  );

  const nextIndex = revenueSeries.length + 30;

  const forecast = {
    revenue: revenueTrend.m * nextIndex + revenueTrend.b,
    profit: profitTrend.m * nextIndex + profitTrend.b,
  };

  return forecast;
}
