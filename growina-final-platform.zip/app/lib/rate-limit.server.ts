import { RateLimiterMemory } from "rate-limiter-flexible";

const limiter = new RateLimiterMemory({
  points: 50,
  duration: 60,
});

export async function checkRateLimit(key: string) {
  try {
    await limiter.consume(key);
    return true;
  } catch {
    return false;
  }
}
