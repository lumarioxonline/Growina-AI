export type ProfitInputs = {
  subtotal: number;
  shippingRevenue: number;
  discounts: number;
  taxes: number;

  refundedSubtotal?: number;
  refundedShipping?: number;
  refundedTaxes?: number;

  cogs: number;
  paymentFeePct: number;
  paymentFeeFixed: number;
  shippingCost: number;
  returnCost: number;
};

export function computeProfit(i: ProfitInputs) {
  const refundedSubtotal = i.refundedSubtotal ?? 0;
  const refundedShipping = i.refundedShipping ?? 0;
  const refundedTaxes = i.refundedTaxes ?? 0;

  const grossRevenue = i.subtotal + i.shippingRevenue - i.discounts;
  const refunds = refundedSubtotal + refundedShipping;

  const netRevenueBeforeTax = grossRevenue - refunds;
  const netTaxes = i.taxes - refundedTaxes;

  const revenue = netRevenueBeforeTax + netTaxes;

  const feesBase = Math.max(0, netRevenueBeforeTax + i.shippingRevenue);
  const fees = Math.max(0, feesBase * i.paymentFeePct + i.paymentFeeFixed);

  const profit = revenue - (i.cogs + fees + i.shippingCost + i.returnCost);
  const marginPct = revenue > 0 ? (profit / revenue) * 100 : 0;

  return { revenue, fees, profit, marginPct };
}
