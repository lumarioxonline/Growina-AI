import axios from "axios";
import { prisma } from "~/db.server";

export async function notifyWebhooks(shopId: string, event: string, payload: any) {
  const hooks = await prisma.webhookIntegration.findMany({ where: { shopId, isActive: true } });
  if (!hooks.length) return;

  await Promise.allSettled(
    hooks.map(async (h) => {
      const body = {
        event,
        shopId,
        ts: new Date().toISOString(),
        payload,
      };
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (h.secret) headers["X-Growina-Secret"] = h.secret;
      await axios.post(h.url, body, { headers, timeout: 5000 });
    })
  );
}
