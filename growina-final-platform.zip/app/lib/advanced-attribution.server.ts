export function scoreTouchpoints(touches:any[]) {
  const weight = 1 / Math.max(1, touches.length);
  return touches.map(t => ({
    ...t,
    score: weight,
  }));
}
