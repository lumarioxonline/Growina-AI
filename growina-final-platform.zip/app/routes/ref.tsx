import { type LoaderFunctionArgs, redirect } from "@remix-run/node";
import { prisma } from "~/db.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const url = new URL(request.url);
  const code = url.searchParams.get("code");

  if (code) {
    const ref = await prisma.referral.findUnique({ where: { code } });
    if (ref) {
      await prisma.referral.update({
        where: { code },
        data: { clicks: { increment: 1 } },
      });
    }
  }

  return redirect("/");
}
