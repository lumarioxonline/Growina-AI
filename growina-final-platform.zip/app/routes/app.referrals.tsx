import { json, type ActionFunctionArgs, type LoaderFunctionArgs } from "@remix-run/node";
import { Form, useActionData, useLoaderData } from "@remix-run/react";
import { Page, Layout, Card, BlockStack, Text, Button, Banner, TextField } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { prisma } from "~/db.server";
import { nanoid } from "nanoid";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = await prisma.shop.findUnique({ where: { shopDomain: session.shop } });
  if (!shop) throw new Error("Shop not found");

  const ref = await prisma.referral.findFirst({ where: { shopId: shop.id }, orderBy: { createdAt: "desc" } });
  return json({ ref, appUrl: process.env.SHOPIFY_APP_URL ?? "" });
}

export async function action({ request }: ActionFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = await prisma.shop.findUnique({ where: { shopDomain: session.shop } });
  if (!shop) throw new Error("Shop not found");

  const code = nanoid(10);
  const ref = await prisma.referral.create({ data: { shopId: shop.id, code } });
  return json({ ok: true, message: "Referral code gemaakt.", ref });
}

export default function Referrals() {
  const { ref, appUrl } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();
  const code = actionData?.ref?.code ?? ref?.code ?? "";
  const link = code ? `${appUrl}/app?ref=${code}` : "";

  return (
    <Page title="Referrals">
      <Layout>
        <Layout.Section>
          {actionData?.message ? (
            <Banner tone="success" title="Gelukt">
              <p>{actionData.message}</p>
            </Banner>
          ) : null}

          <Card>
            <BlockStack gap="300">
              <Text as="h2" variant="headingMd">Referral link</Text>
              <Text as="p" tone="subdued">Gebruik dit om agencies/collega’s te laten installen (tracking in DB).</Text>
              <Form method="post">
                <Button submit variant="primary">Maak nieuwe referral</Button>
              </Form>
              <TextField label="Code" value={code} readOnly autoComplete="off" />
              <TextField label="Link" value={link} readOnly autoComplete="off" />
              {ref ? (
                <Text as="p">Clicks: <b>{ref.clicks}</b> • Installs: <b>{ref.installs}</b></Text>
              ) : null}
            </BlockStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
