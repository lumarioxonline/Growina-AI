export async function loader(){return new Response('ok');}
