import { json, type LoaderFunctionArgs } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { Page, Layout, Card, DataTable } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { getProductProfitTable } from "~/models/orders.server";
import { formatMoney, formatPct } from "~/lib/format";
import { prisma } from "~/db.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;
  const shopRow = await prisma.shop.findUnique({ where: { shopDomain: shop } });
  const currency = shopRow?.currency ?? "EUR";
  const rows = await getProductProfitTable(shop, 30, 100);
  return json({ currency, rows });
}

export default function Products() {
  const { rows, currency } = useLoaderData<typeof loader>();

  const tableRows = rows.map((r) => [
    r.product,
    r.sku,
    formatMoney(r.revenue, currency),
    formatMoney(r.profit, currency),
    formatPct(r.marginPct),
    String(r.orders),
    String(r.qty),
  ]);

  return (
    <Page title="Product winst">
      <Layout>
        <Layout.Section>
          <Card>
            <DataTable
              columnContentTypes={["text","text","numeric","numeric","numeric","numeric","numeric"]}
              headings={["Product","SKU","Omzet","Winst","Marge","Orders","Aantal"]}
              rows={tableRows}
              footerContent="Periode: laatste 30 dagen"
            />
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
