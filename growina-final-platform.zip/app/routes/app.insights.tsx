import { json, type LoaderFunctionArgs } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { Page, Layout, Card, BlockStack, Text } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { prisma } from "~/db.server";
import { formatMoney, formatPct } from "~/lib/format";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shopDomain = session.shop;
  const shop = await prisma.shop.findUnique({ where: { shopDomain } });
  if (!shop) throw new Error("Shop not found");

  const missingCogs = await prisma.variant.count({ where: { shopId: shop.id, cost: null } });

  const since = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const orders = await prisma.order.findMany({
    where: { shopId: shop.id, createdAt: { gte: since } },
    select: { revenue: true, profit: true, createdAt: true },
  });
  const revenue = orders.reduce((a, o) => a + o.revenue, 0);
  const profitBeforeAds = orders.reduce((a, o) => a + o.profit, 0);

  const adSpendRows = await prisma.adSpendDaily.findMany({
    where: { shopId: shop.id, date: { gte: since } },
    select: { spend: true },
  });
  const adSpend = adSpendRows.reduce((a,r)=>a+r.spend,0);

  const profit = profitBeforeAds - adSpend;
  const marginPct = revenue > 0 ? (profit / revenue) * 100 : 0;

  const dayMap = new Map<string, number>();
  for (const o of orders) {
    const day = o.createdAt.toISOString().slice(0,10);
    dayMap.set(day, (dayMap.get(day) ?? 0) + o.profit);
  }
  const lossDays = Array.from(dayMap.values()).filter(v => v < 0);
  const totalLoss = lossDays.reduce((a,v)=>a+Math.abs(v),0);

  return json({ currency: shop.currency, missingCogs, revenue, profit, profitBeforeAds, adSpend, marginPct, totalLoss });
}

export default function Insights() {
  const d = useLoaderData<typeof loader>();
  return (
    <Page title="Insights">
      <Layout>
        <Layout.Section>
          <Card>
            <BlockStack gap="200">
              <Text as="h2" variant="headingMd">Gezondheid (30 dagen)</Text>
              <Text as="p">Omzet: <b>{formatMoney(d.revenue, d.currency)}</b></Text>
              <Text as="p">Winst vóór ads: <b>{formatMoney(d.profitBeforeAds, d.currency)}</b></Text>
              <Text as="p">Ad spend: <b>{formatMoney(d.adSpend, d.currency)}</b></Text>
              <Text as="p">Netto winst: <b>{formatMoney(d.profit, d.currency)}</b></Text>
              <Text as="p">Marge: <b>{formatPct(d.marginPct)}</b></Text>
              <Text as="p">Missende COGS (varianten): <b>{d.missingCogs}</b></Text>
              <Text as="p" tone="subdued">Verlies-dagen totaal (indicatie, vóór ads): {formatMoney(d.totalLoss, d.currency)}</Text>
            </BlockStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
