import { json, type LoaderFunctionArgs } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { Page, Layout, Card, BlockStack, Text } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { prisma } from "~/db.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const teams = await prisma.team.findMany({
    where: { ownerId: session.shop },
  });
  return json({ teams });
}

export default function Agency() {
  const { teams } = useLoaderData<typeof loader>();

  return (
    <Page title="Agency">
      <Layout>
        <Layout.Section>
          <Card>
            <BlockStack gap="200">
              <Text as="h2" variant="headingMd">Store portfolio</Text>
              <ul>
                {teams.map((t:any)=>(
                  <li key={t.id}>{t.name}</li>
                ))}
              </ul>
            </BlockStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
