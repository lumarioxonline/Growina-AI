import { json, type ActionFunctionArgs, type LoaderFunctionArgs } from "@remix-run/node";
import { Form, useLoaderData } from "@remix-run/react";
import { Page, Layout, Card, DataTable, Button, InlineStack, Text } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { listDailyReports } from "~/models/reports.server";
import { formatMoney, formatPct } from "~/lib/format";
import Papa from "papaparse";
import { prisma } from "~/db.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;
  const shopRow = await prisma.shop.findUnique({ where: { shopDomain: shop } });
  const currency = shopRow?.currency ?? "EUR";
  const reports = await listDailyReports(shop, 60);
  return json({ currency, reports });
}

export async function action({ request }: ActionFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;
  const reports = await listDailyReports(shop, 365);

  const csv = Papa.unparse(
    reports.map((r) => ({
      date: r.date.toISOString().slice(0, 10),
      revenue: r.revenue,
      profit: r.profit,
      marginPct: r.marginPct,
    }))
  );

  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": "attachment; filename=\"growina-daily-reports.csv\"",
    },
  });
}

export default function Reports() {
  const { reports, currency } = useLoaderData<typeof loader>();

  const rows = reports.map((r) => [
    r.date.toISOString().slice(0, 10),
    formatMoney(r.revenue, currency),
    formatMoney(r.profit, currency),
    formatPct(r.marginPct),
  ]);

  return (
    <Page title="Daily Reports">
      <Layout>
        <Layout.Section>
          <Card>
            <InlineStack align="space-between">
              <Text as="h2" variant="headingMd">Laatste 60 dagen</Text>
              <Form method="post">
                <Button submit>Export CSV</Button>
              </Form>
            </InlineStack>
            <div style={{ marginTop: 12 }}>
              <DataTable
                columnContentTypes={["text","numeric","numeric","numeric"]}
                headings={["Datum","Omzet","Winst","Marge"]}
                rows={rows}
              />
            </div>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
