import { json, type ActionFunctionArgs, type LoaderFunctionArgs } from "@remix-run/node";
import { Form, useActionData, useLoaderData } from "@remix-run/react";
import { Page, Layout, Card, BlockStack, Text, Button, Banner, Select } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { prisma } from "~/db.server";
import { backfillOrders } from "~/lib/backfill.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = await prisma.shop.findUnique({ where: { shopDomain: session.shop } });
  if (!shop) throw new Error("Shop not found");

  const jobs = await prisma.syncJob.findMany({
    where: { shopId: shop.id },
    orderBy: { createdAt: "desc" },
    take: 10,
  });

  return json({ jobs });
}

export async function action({ request }: ActionFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shopRow = await prisma.shop.findUnique({ where: { shopDomain: session.shop } });
  if (!shopRow) throw new Error("Shop not found");

  const form = await request.formData();
  const days = Number(form.get("days") ?? 90);
  const safeDays = Number.isFinite(days) ? Math.max(7, Math.min(365, days)) : 90;

  const job = await prisma.syncJob.create({
    data: { shopId: shopRow.id, type: "BACKFILL_ORDERS", status: "running", startedAt: new Date() },
  });

  try {
    const result = await backfillOrders({ shopDomain: session.shop, accessToken: session.accessToken, days: safeDays });
    await prisma.syncJob.update({
      where: { id: job.id },
      data: { status: "done", endedAt: new Date(), message: `Backfill ok. Orders verwerkt: ${result.total} (sinds ${result.since})` },
    });
    return json({ ok: true, message: "Sync klaar (eerste pagina van 250 orders verwerkt).", result });
  } catch (e: any) {
    await prisma.syncJob.update({
      where: { id: job.id },
      data: { status: "failed", endedAt: new Date(), message: String(e?.message ?? e) },
    });
    return json({ ok: false, message: String(e?.message ?? e) }, { status: 500 });
  }
}

export default function Sync() {
  const { jobs } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();

  return (
    <Page title="Sync / Backfill">
      <Layout>
        <Layout.Section>
          {actionData?.message ? (
            <Banner tone={actionData.ok ? "success" : "critical"} title={actionData.ok ? "Gelukt" : "Fout"}>
              <p>{actionData.message}</p>
            </Banner>
          ) : null}

          <Card>
            <BlockStack gap="300">
              <Text as="h2" variant="headingMd">Orders backfill</Text>
              <Text as="p" tone="subdued">
                Haal automatisch orders binnen van de afgelopen X dagen (MVP: tot 250 orders per run).
              </Text>
              <Form method="post">
                <Select
                  label="Periode"
                  name="days"
                  options={[
                    { label: "30 dagen", value: "30" },
                    { label: "90 dagen", value: "90" },
                    { label: "180 dagen", value: "180" },
                    { label: "365 dagen", value: "365" },
                  ]}
                />
                <div style={{ marginTop: 12 }}>
                  <Button submit variant="primary">Start backfill</Button>
                </div>
              </Form>
            </BlockStack>
          </Card>

          <div style={{ height: 16 }} />

          <Card>
            <BlockStack gap="200">
              <Text as="h2" variant="headingMd">Laatste jobs</Text>
              <ul>
                {jobs.map((j) => (
                  <li key={j.id}>
                    <b>{j.type}</b> — {j.status} — {j.message ?? "—"} — {new Date(j.createdAt).toISOString()}
                  </li>
                ))}
              </ul>
            </BlockStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
