import { json, type LoaderFunctionArgs } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { Page, Layout, Card, DataTable } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { prisma } from "~/db.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);

  const shop = await prisma.shop.findUnique({
    where: { shopDomain: session.shop },
  });
  if (!shop) throw new Error("Shop not found");

  const rows = await prisma.campaignMetric.findMany({
    where: { shopId: shop.id },
    orderBy: { date: "desc" },
    take: 100,
  });

  return json({ rows });
}

export default function Campaigns() {
  const { rows } = useLoaderData<typeof loader>();

  const table = rows.map(r => [
    r.source,
    r.campaign,
    r.spend.toFixed(2),
    r.revenue.toFixed(2),
    r.profit.toFixed(2),
  ]);

  return (
    <Page title="Campaign Profit">
      <Layout>
        <Layout.Section>
          <Card>
            <DataTable
              columnContentTypes={["text","text","numeric","numeric","numeric"]}
              headings={["Source","Campaign","Spend","Revenue","Profit"]}
              rows={table}
            />
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
