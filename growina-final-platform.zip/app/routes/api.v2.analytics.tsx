import { json, type LoaderFunctionArgs } from "@remix-run/node";

export async function loader() {
  return json({
    status: "ok",
    version: "v2",
    message: "Growina analytics API",
  });
}
