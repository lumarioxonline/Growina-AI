import { type LoaderFunctionArgs, json } from "@remix-run/node";
import { prisma } from "~/db.server";
import crypto from "crypto";

function sha256(s: string) {
  return crypto.createHash("sha256").update(s).digest("hex");
}

export async function loader({ request }: LoaderFunctionArgs) {
  const auth = request.headers.get("authorization") || "";
  const token = auth.startsWith("Bearer ") ? auth.slice("Bearer ".length) : "";
  if (!token) return json({ error: "missing_token" }, { status: 401 });

  const tokenHash = sha256(token);
  const apiKey = await prisma.apiKey.findFirst({ where: { tokenHash, revokedAt: null } });
  if (!apiKey) return json({ error: "invalid_token" }, { status: 403 });

  const shop = await prisma.shop.findUnique({ where: { id: apiKey.shopId } });
  if (!shop) return json({ error: "shop_not_found" }, { status: 404 });

  const since = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const orders = await prisma.order.findMany({
    where: { shopId: shop.id, createdAt: { gte: since } },
    orderBy: { createdAt: "desc" },
    take: 5000,
  });

  const reports = await prisma.dailyReport.findMany({
    where: { shopId: shop.id },
    orderBy: { date: "desc" },
    take: 365,
  });

  return json({ shop: shop.shopDomain, currency: shop.currency, orders, reports });
}
