import { json, type LoaderFunctionArgs, redirect } from "@remix-run/node";
import { Outlet, useLocation, useNavigate } from "@remix-run/react";
import { Frame, Navigation, TopBar } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { prisma } from "~/db.server";
import { upsertShop } from "~/models/shop.server";
import { requireActivePlan } from "~/lib/billing.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shopDomain = session.shop;
  await upsertShop(shopDomain);

  const shop = await prisma.shop.findUnique({ where: { shopDomain } });
  const url = new URL(request.url);

  if (shop && !shop.onboardingCompleted && !url.pathname.startsWith("/app/onboarding")) {
    return redirect("/app/onboarding");
  }

  if (!url.pathname.startsWith("/app/onboarding") && !url.pathname.startsWith("/app/billing")) {
    await requireActivePlan(request);
  }

  return json({ shop: shopDomain });
}

export default function AppFrame() {
  const location = useLocation();
  const navigate = useNavigate();

  const items = [
    { label: "Dashboard", url: "/app" },
    { label: "Insights", url: "/app/insights" },
    { label: "Forecast", url: "/app/forecast" },
    { label: "Campaigns", url: "/app/campaigns" },
    { label: "AI Decisions", url: "/app/decisions" },
    { label: "Agency", url: "/app/agency" },
    { label: "Teams", url: "/app/teams" },
    { label: "White-label", url: "/app/whitelabel" },
    { label: "Features", url: "/app/features" },
    { label: "Alerts", url: "/app/alert-channels" },
    { label: "Billing", url: "/app/billing" },
    { label: "Settings", url: "/app/settings" },
  ].map(i => ({
    ...i,
    selected: location.pathname === i.url,
    onClick: () => navigate(i.url),
  }));

  return (
    <Frame topBar={<TopBar />} navigation={<Navigation location={location.pathname}>
      <Navigation.Section items={items} />
    </Navigation>}>
      <Outlet />
    </Frame>
  );
}
