import { json, type ActionFunctionArgs, type LoaderFunctionArgs } from "@remix-run/node";
import { Form, useActionData, useLoaderData } from "@remix-run/react";
import { Page, Layout, Card, BlockStack, InlineStack, Text, Select, TextField, Button, Banner } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { listAlertRules, upsertAlertRule, deleteAlertRule } from "~/models/alerts.server";

const OPTIONS = [
  { label: "Winst onder (per dag)", value: "PROFIT_BELOW" },
  { label: "Marge onder (%)", value: "MARGIN_BELOW" },
  { label: "Shipping cost boven (per order)", value: "SHIPPING_ABOVE" },
];

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const rules = await listAlertRules(session.shop);
  return json({ rules });
}

export async function action({ request }: ActionFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const form = await request.formData();
  const intent = String(form.get("intent") ?? "upsert");

  const type = String(form.get("type") ?? "");
  if (!type) return json({ ok: false, message: "Type ontbreekt." }, { status: 400 });

  if (intent === "delete") {
    await deleteAlertRule(session.shop, type);
    return json({ ok: true, message: "Alert verwijderd." });
  }

  const thresholdRaw = String(form.get("threshold") ?? "");
  const threshold = thresholdRaw === "" ? null : Number(thresholdRaw);
  if (thresholdRaw !== "" && !Number.isFinite(threshold as any)) {
    return json({ ok: false, message: "Drempel moet een nummer zijn." }, { status: 400 });
  }

  await upsertAlertRule(session.shop, { type, threshold });
  return json({ ok: true, message: "Alert opgeslagen." });
}

export default function Alerts() {
  const { rules } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();

  return (
    <Page title="Alerts">
      <Layout>
        <Layout.Section>
          {actionData?.message ? (
            <Banner tone={actionData.ok ? "success" : "critical"} title={actionData.ok ? "Gelukt" : "Fout"}>
              <p>{actionData.message}</p>
            </Banner>
          ) : null}

          <Card>
            <BlockStack gap="300">
              <Text as="h2" variant="headingMd">Nieuwe / update alert</Text>

              <Form method="post">
                <BlockStack gap="300">
                  <Select label="Type" name="type" options={OPTIONS} />
                  <TextField label="Drempel" name="threshold" autoComplete="off" helpText="Bijv 100 (EUR) of 20 (%)" />
                  <InlineStack gap="300">
                    <Button submit variant="primary">Opslaan</Button>
                  </InlineStack>
                </BlockStack>
              </Form>
            </BlockStack>
          </Card>

          <div style={{ height: 16 }} />

          <Card>
            <BlockStack gap="300">
              <Text as="h2" variant="headingMd">Huidige alerts</Text>
              <ul>
                {rules.map((r) => (
                  <li key={r.id}>
                    <b>{r.type}</b> — threshold: {r.threshold ?? "—"} — actief: {r.isActive ? "ja" : "nee"}
                    <Form method="post" style={{ display: "inline", marginLeft: 12 }}>
                      <input type="hidden" name="intent" value="delete" />
                      <input type="hidden" name="type" value={r.type} />
                      <Button submit tone="critical" size="micro">Verwijder</Button>
                    </Form>
                  </li>
                ))}
              </ul>
            </BlockStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
