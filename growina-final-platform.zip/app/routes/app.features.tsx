import { Page, Layout, Card, Text } from "@shopify/polaris";

export default function Features() {
  return (
    <Page title="Experiments">
      <Layout>
        <Layout.Section>
          <Card>
            <Text>Feature flags & A/B testing foundation.</Text>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
