import { json, type LoaderFunctionArgs, type ActionFunctionArgs } from "@remix-run/node";
import { useLoaderData, Form, useActionData } from "@remix-run/react";
import { Page, Layout, Card, Text, BlockStack, TextField, Button, Banner } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { prisma } from "~/db.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = await prisma.shop.findUnique({ where: { shopDomain: session.shop } });
  const channels = await prisma.alertChannel.findMany({ where: { shopId: shop?.id } });
  return json({ channels });
}

export async function action({ request }: ActionFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = await prisma.shop.findUnique({ where: { shopDomain: session.shop } });

  const form = await request.formData();
  const type = String(form.get("type"));
  const config = String(form.get("config"));

  await prisma.alertChannel.create({
    data: { shopId: shop!.id, type, config },
  });

  return json({ ok: true, message: "Kanaal toegevoegd." });
}

export default function Channels() {
  const { channels } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();

  return (
    <Page title="Alert Channels">
      <Layout>
        <Layout.Section>
          {actionData?.message ? (
            <Banner tone="success"><p>{actionData.message}</p></Banner>
          ) : null}

          <Card>
            <BlockStack gap="300">
              <Text as="h2" variant="headingMd">Nieuw alert kanaal</Text>
              <Form method="post">
                <TextField label="Type (slack/telegram/email)" name="type" />
                <TextField label="Config (webhook of chatId)" name="config" />
                <Button submit variant="primary">Toevoegen</Button>
              </Form>
            </BlockStack>
          </Card>

          <div style={{height:20}} />

          <Card>
            <BlockStack gap="200">
              <Text as="h2" variant="headingMd">Actieve kanalen</Text>
              <ul>
                {channels.map((c:any)=>(
                  <li key={c.id}>{c.type} – {c.config}</li>
                ))}
              </ul>
            </BlockStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
