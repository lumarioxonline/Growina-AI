import { json, type LoaderFunctionArgs } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { Page, Layout, Card, Text, BlockStack } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { prisma } from "~/db.server";
import { generateForecast } from "~/lib/forecast.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = await prisma.shop.findUnique({
    where: { shopDomain: session.shop },
  });
  if (!shop) throw new Error("Shop not found");

  const forecast = await generateForecast(shop.id);
  return json({ forecast, currency: shop.currency });
}

export default function Forecast() {
  const { forecast, currency } = useLoaderData<typeof loader>();

  return (
    <Page title="AI Forecast">
      <Layout>
        <Layout.Section>
          <Card>
            <BlockStack gap="200">
              <Text as="h2" variant="headingMd">30 dagen voorspelling</Text>
              {forecast ? (
                <>
                  <Text>Omzet: {forecast.revenue.toFixed(2)} {currency}</Text>
                  <Text>Winst: {forecast.profit.toFixed(2)} {currency}</Text>
                </>
              ) : (
                <Text>Niet genoeg data.</Text>
              )}
            </BlockStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
