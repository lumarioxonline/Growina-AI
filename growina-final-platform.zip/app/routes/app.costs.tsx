import { json, type ActionFunctionArgs, type LoaderFunctionArgs } from "@remix-run/node";
import { Form, useActionData, useLoaderData } from "@remix-run/react";
import { Page, Layout, Card, Text, BlockStack, InlineStack, TextField, Button, Banner } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { bulkUpsertVariantCostsFromSku, listVariantsMissingCogs } from "~/models/variants.server";

function parseCsv(text: string): Array<{ sku: string; cost: number }> {
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const out: Array<{ sku: string; cost: number }> = [];
  for (const line of lines) {
    const parts = line.split(",").map((p) => p.trim());
    if (parts.length < 2) continue;
    const sku = parts[0];
    const cost = Number(parts[1]);
    if (!sku || !Number.isFinite(cost)) continue;
    out.push({ sku, cost });
  }
  return out;
}

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;
  const missing = await listVariantsMissingCogs(shop, 50);
  return json({ missing });
}

export async function action({ request }: ActionFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;

  const form = await request.formData();
  const csv = String(form.get("csv") ?? "");
  const rows = parseCsv(csv);

  if (rows.length === 0) {
    return json({ ok: false, message: "CSV leeg of ongeldig. Gebruik: SKU,kostprijs per regel." }, { status: 400 });
  }

  const results = await bulkUpsertVariantCostsFromSku({ shopDomain: shop, rows });
  const updatedTotal = results.reduce((a, r) => a + r.updated, 0);

  return json({ ok: true, message: `Klaar! ${updatedTotal} varianten bijgewerkt.` });
}

export default function Costs() {
  const { missing } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();

  return (
    <Page title="COGS / Kostprijzen">
      <Layout>
        <Layout.Section>
          {actionData?.message ? (
            <Banner tone={actionData.ok ? "success" : "critical"} title={actionData.ok ? "Gelukt" : "Fout"}>
              <p>{actionData.message}</p>
            </Banner>
          ) : null}

          <Card>
            <BlockStack gap="300">
              <Text as="h2" variant="headingMd">CSV import</Text>
              <Text as="p" tone="subdued">Plak CSV met per regel: <b>SKU,kostprijs</b>. Voorbeeld: ABC123,4.20</Text>

              <Form method="post">
                <BlockStack gap="300">
                  <TextField label="CSV" name="csv" multiline={6} autoComplete="off" />
                  <InlineStack gap="300">
                    <Button submit variant="primary">Importeer</Button>
                  </InlineStack>
                </BlockStack>
              </Form>
            </BlockStack>
          </Card>

          <div style={{ height: 16 }} />

          <Card>
            <BlockStack gap="300">
              <Text as="h2" variant="headingMd">Missende kostprijzen (top 50)</Text>
              <Text as="p" tone="subdued">Voeg kostprijzen toe om winstberekening correct te maken.</Text>
              <ul>
                {missing.map((v) => (
                  <li key={v.id}>
                    {v.product?.title ?? "—"} — SKU: {v.sku ?? "—"} — Variant: {v.title ?? "—"}
                  </li>
                ))}
              </ul>
            </BlockStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
