import { json, type ActionFunctionArgs, type LoaderFunctionArgs } from "@remix-run/node";
import { Form, useActionData, useLoaderData } from "@remix-run/react";
import { Page, Layout, Card, BlockStack, Text, TextField, Button, Banner } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { prisma } from "~/db.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = await prisma.shop.findUnique({ where: { shopDomain: session.shop } });
  if (!shop) throw new Error("Shop not found");

  const hooks = await prisma.webhookIntegration.findMany({
    where: { shopId: shop.id },
    orderBy: { createdAt: "desc" },
  });

  return json({ hooks });
}

export async function action({ request }: ActionFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = await prisma.shop.findUnique({ where: { shopDomain: session.shop } });
  if (!shop) throw new Error("Shop not found");

  const form = await request.formData();
  const intent = String(form.get("intent") ?? "create");

  if (intent === "delete") {
    const id = String(form.get("id") ?? "");
    await prisma.webhookIntegration.delete({ where: { id } });
    return json({ ok: true, message: "Integratie verwijderd." });
  }

  const name = String(form.get("name") ?? "Webhook");
  const url = String(form.get("url") ?? "");
  const secret = String(form.get("secret") ?? "");

  if (!url.startsWith("http")) {
    return json({ ok: false, message: "URL ongeldig (moet http/https zijn)." }, { status: 400 });
  }

  await prisma.webhookIntegration.create({
    data: { shopId: shop.id, name, url, secret: secret || null, isActive: true },
  });

  return json({ ok: true, message: "Integratie toegevoegd." });
}

export default function Integrations() {
  const { hooks } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();

  return (
    <Page title="Integraties">
      <Layout>
        <Layout.Section>
          {actionData?.message ? (
            <Banner tone={actionData.ok ? "success" : "critical"} title={actionData.ok ? "Gelukt" : "Fout"}>
              <p>{actionData.message}</p>
            </Banner>
          ) : null}

          <Card>
            <BlockStack gap="300">
              <Text as="h2" variant="headingMd">Webhook notificaties</Text>
              <Text as="p" tone="subdued">
                Voeg een webhook URL toe om alerts & daily reports door te sturen (bijv. Make.com, Zapier, Telegram bot endpoint, Slack webhook).
              </Text>
              <Form method="post">
                <BlockStack gap="300">
                  <TextField label="Naam" name="name" autoComplete="off" />
                  <TextField label="Webhook URL" name="url" autoComplete="off" />
                  <TextField label="Secret (optioneel)" name="secret" autoComplete="off" />
                  <Button submit variant="primary">Toevoegen</Button>
                </BlockStack>
              </Form>
            </BlockStack>
          </Card>

          <div style={{ height: 16 }} />

          <Card>
            <BlockStack gap="200">
              <Text as="h2" variant="headingMd">Actieve integraties</Text>
              <ul>
                {hooks.map((h) => (
                  <li key={h.id}>
                    <b>{h.name}</b> — {h.url}
                    <Form method="post" style={{ display: "inline", marginLeft: 12 }}>
                      <input type="hidden" name="intent" value="delete" />
                      <input type="hidden" name="id" value={h.id} />
                      <Button submit tone="critical" size="micro">Verwijder</Button>
                    </Form>
                  </li>
                ))}
              </ul>
            </BlockStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
