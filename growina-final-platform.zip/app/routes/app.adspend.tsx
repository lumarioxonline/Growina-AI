import { json, type ActionFunctionArgs, type LoaderFunctionArgs } from "@remix-run/node";
import { Form, useActionData, useLoaderData } from "@remix-run/react";
import { Page, Layout, Card, Text, BlockStack, TextField, Button, Banner, Select, DataTable } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { prisma } from "~/db.server";

function parseCsv(text: string) {
  // date,source,spend,campaign(optional)
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const out: Array<{ date: string; source: string; spend: number; campaign?: string }> = [];
  for (const line of lines) {
    const parts = line.split(",").map((p) => p.trim());
    if (parts.length < 3) continue;
    const date = parts[0];
    const source = parts[1].toUpperCase();
    const spend = Number(parts[2]);
    const campaign = parts[3] ? parts[3] : undefined;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) continue;
    if (!Number.isFinite(spend)) continue;
    out.push({ date, source, spend, campaign });
  }
  return out;
}

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = await prisma.shop.findUnique({ where: { shopDomain: session.shop } });
  if (!shop) throw new Error("Shop not found");

  const rows = await prisma.adSpendDaily.findMany({
    where: { shopId: shop.id },
    orderBy: [{ date: "desc" }, { createdAt: "desc" }],
    take: 100,
  });

  return json({ currency: shop.currency, rows });
}

export async function action({ request }: ActionFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = await prisma.shop.findUnique({ where: { shopDomain: session.shop } });
  if (!shop) throw new Error("Shop not found");

  const form = await request.formData();
  const csv = String(form.get("csv") ?? "");
  const parsed = parseCsv(csv);

  if (parsed.length === 0) {
    return json({ ok: false, message: "CSV ongeldig. Gebruik: YYYY-MM-DD,SOURCE,SPEND,CAMPAIGN" }, { status: 400 });
  }

  await prisma.adSpendDaily.createMany({
    data: parsed.map((r) => ({
      shopId: shop.id,
      date: new Date(r.date + "T00:00:00.000Z"),
      source: r.source,
      campaign: r.campaign,
      spend: r.spend,
      currency: shop.currency,
    })),
  });

  return json({ ok: true, message: `Toegevoegd: ${parsed.length} ad spend regels.` });
}

export default function AdSpend() {
  const { rows, currency } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();

  const tableRows = rows.map((r) => [
    r.date.toISOString().slice(0,10),
    r.source,
    r.campaign ?? "—",
    `${r.spend.toFixed(2)} ${currency}`,
  ]);

  return (
    <Page title="Ad Spend">
      <Layout>
        <Layout.Section>
          {actionData?.message ? (
            <Banner tone={actionData.ok ? "success" : "critical"} title={actionData.ok ? "Gelukt" : "Fout"}>
              <p>{actionData.message}</p>
            </Banner>
          ) : null}

          <Card>
            <BlockStack gap="300">
              <Text as="h2" variant="headingMd">CSV import</Text>
              <Text as="p" tone="subdued">Per regel: <b>YYYY-MM-DD,SOURCE,SPEND,CAMPAIGN</b>. SOURCE: META/GOOGLE/TIKTOK/OTHER</Text>
              <Form method="post">
                <BlockStack gap="300">
                  <TextField label="CSV" name="csv" multiline={6} autoComplete="off" />
                  <Button submit variant="primary">Importeer</Button>
                </BlockStack>
              </Form>
            </BlockStack>
          </Card>

          <div style={{ height: 16 }} />

          <Card>
            <DataTable
              columnContentTypes={["text","text","text","numeric"]}
              headings={["Datum","Source","Campaign","Spend"]}
              rows={tableRows}
              footerContent="Laatste 100 regels"
            />
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
