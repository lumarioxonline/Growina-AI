import { json, type LoaderFunctionArgs, type ActionFunctionArgs } from "@remix-run/node";
import { useLoaderData, Form } from "@remix-run/react";
import { Page, Layout, Card, TextField, Button, BlockStack } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { prisma } from "~/db.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = await prisma.shop.findUnique({ where: { shopDomain: session.shop } });
  const wl = await prisma.whiteLabel.findFirst({ where: { shopId: shop?.id } });
  return json({ wl });
}

export async function action({ request }: ActionFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = await prisma.shop.findUnique({ where: { shopDomain: session.shop } });

  const form = await request.formData();
  const brandName = String(form.get("brandName") ?? "");
  const logoUrl = String(form.get("logoUrl") ?? "");
  const primary = String(form.get("primary") ?? "");

  await prisma.whiteLabel.upsert({
    where: { shopId: shop!.id },
    update: { brandName, logoUrl, primary },
    create: { shopId: shop!.id, brandName, logoUrl, primary },
  });

  return json({ ok: true });
}

export default function WL() {
  const { wl } = useLoaderData<typeof loader>();

  return (
    <Page title="White-label">
      <Layout>
        <Layout.Section>
          <Card>
            <Form method="post">
              <BlockStack gap="300">
                <TextField name="brandName" label="Brand naam" defaultValue={wl?.brandName} />
                <TextField name="logoUrl" label="Logo URL" defaultValue={wl?.logoUrl} />
                <TextField name="primary" label="Kleur" defaultValue={wl?.primary} />
                <Button submit variant="primary">Opslaan</Button>
              </BlockStack>
            </Form>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
