import { json, type LoaderFunctionArgs, type ActionFunctionArgs } from "@remix-run/node";
import { useLoaderData, Form, useActionData } from "@remix-run/react";
import { Page, Layout, Card, BlockStack, Text, Button, TextField, Banner } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { prisma } from "~/db.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);

  const teams = await prisma.team.findMany({
    where: { ownerId: session.shop },
    include: { users: true },
  });

  return json({ teams });
}

export async function action({ request }: ActionFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const form = await request.formData();

  const intent = String(form.get("intent") ?? "create");

  if (intent === "create") {
    const name = String(form.get("name") ?? "Team");

    await prisma.team.create({
      data: { name, ownerId: session.shop },
    });

    return json({ ok: true, message: "Team aangemaakt." });
  }

  if (intent === "invite") {
    const teamId = String(form.get("teamId"));
    const email = String(form.get("email"));

    await prisma.teamUser.create({
      data: { teamId, email, role: "viewer" },
    });

    return json({ ok: true, message: "Uitnodiging opgeslagen." });
  }

  return json({ ok: false });
}

export default function Teams() {
  const { teams } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();

  return (
    <Page title="Teams">
      <Layout>
        <Layout.Section>
          {actionData?.message ? (
            <Banner tone="success"><p>{actionData.message}</p></Banner>
          ) : null}

          <Card>
            <BlockStack gap="300">
              <Text as="h2" variant="headingMd">Nieuw team</Text>
              <Form method="post">
                <input type="hidden" name="intent" value="create" />
                <TextField name="name" label="Naam" autoComplete="off" />
                <Button submit variant="primary">Maak team</Button>
              </Form>
            </BlockStack>
          </Card>

          <div style={{height:20}} />

          {teams.map((t:any)=>(
            <Card key={t.id}>
              <BlockStack gap="200">
                <Text as="h3" variant="headingSm">{t.name}</Text>

                <Form method="post">
                  <input type="hidden" name="intent" value="invite" />
                  <input type="hidden" name="teamId" value={t.id} />
                  <TextField name="email" label="Nodig gebruiker uit" autoComplete="off" />
                  <Button submit>Invite</Button>
                </Form>

                <ul>
                  {t.users.map((u:any)=>(
                    <li key={u.id}>{u.email} – {u.role}</li>
                  ))}
                </ul>
              </BlockStack>
            </Card>
          ))}
        </Layout.Section>
      </Layout>
    </Page>
  );
}
