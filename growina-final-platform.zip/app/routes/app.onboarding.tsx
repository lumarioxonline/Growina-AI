import { json, type ActionFunctionArgs, type LoaderFunctionArgs, redirect } from "@remix-run/node";
import { Form, useActionData, useLoaderData } from "@remix-run/react";
import { Page, Layout, Card, BlockStack, Text, Button, Banner, InlineStack, ProgressBar } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { prisma } from "~/db.server";
import { upsertShop } from "~/models/shop.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shopDomain = session.shop;
  await upsertShop(shopDomain);
  const shop = await prisma.shop.findUnique({ where: { shopDomain } });
  if (!shop) throw new Error("Shop not found");
  if (shop.onboardingCompleted) return redirect("/app");
  return json({ step: shop.onboardingStep, shop });
}

export async function action({ request }: ActionFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shopDomain = session.shop;
  const shop = await prisma.shop.findUnique({ where: { shopDomain } });
  if (!shop) throw new Error("Shop not found");

  const form = await request.formData();
  const intent = String(form.get("intent") ?? "next");

  if (intent === "skip") {
    await prisma.shop.update({ where: { shopDomain }, data: { onboardingCompleted: true } });
    return redirect("/app");
  }

  const nextStep = Math.min(4, (shop.onboardingStep ?? 1) + 1);
  const completed = nextStep >= 4;

  await prisma.shop.update({
    where: { shopDomain },
    data: { onboardingStep: nextStep, onboardingCompleted: completed },
  });

  if (completed) return redirect("/app");
  return json({ ok: true, message: "Volgende stap." });
}

export default function Onboarding() {
  const { step } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();

  const pct = Math.round(((step - 1) / 3) * 100);

  const steps = [
    { n: 1, title: "Instellingen", body: "Stel je payment fee en gemiddelde shipping/return kosten in." , link: "/app/settings" },
    { n: 2, title: "COGS toevoegen", body: "Importeer kostprijzen via CSV zodat winst klopt.", link: "/app/costs" },
    { n: 3, title: "Alerts", body: "Maak minimaal 1 alert (bijv. marge < 20%).", link: "/app/alerts" },
  ];

  const current = steps.find(s => s.n === step) ?? steps[0];

  return (
    <Page title="Onboarding">
      <Layout>
        <Layout.Section>
          {actionData?.message ? (
            <Banner tone="success" title="Oké">
              <p>{actionData.message}</p>
            </Banner>
          ) : null}

          <Card>
            <BlockStack gap="300">
              <Text as="h2" variant="headingMd">Growina setup ({step}/4)</Text>
              <ProgressBar progress={pct} />
              <Text as="p" tone="subdued">
                Volg deze stappen zodat je binnen 10 minuten echte winst ziet.
              </Text>

              {step <= 3 ? (
                <Card>
                  <BlockStack gap="200">
                    <Text as="h3" variant="headingSm">{current.title}</Text>
                    <Text as="p">{current.body}</Text>
                    <InlineStack gap="300">
                      <Button url={current.link}>Open {current.title}</Button>
                      <Form method="post">
                        <input type="hidden" name="intent" value="next" />
                        <Button submit variant="primary">Ik heb dit gedaan</Button>
                      </Form>
                    </InlineStack>
                  </BlockStack>
                </Card>
              ) : (
                <Text as="p">Klaar! Je wordt doorgestuurd.</Text>
              )}

              <Form method="post">
                <input type="hidden" name="intent" value="skip" />
                <Button submit tone="critical" variant="plain">Onboarding overslaan</Button>
              </Form>
            </BlockStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
