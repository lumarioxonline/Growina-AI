import { json, type ActionFunctionArgs, type LoaderFunctionArgs } from "@remix-run/node";
import { Form, useActionData, useLoaderData } from "@remix-run/react";
import { Page, Layout, Card, BlockStack, Text, TextField, Button, Banner } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { prisma } from "~/db.server";
import crypto from "crypto";
import { nanoid } from "nanoid";

function sha256(s: string) {
  return crypto.createHash("sha256").update(s).digest("hex");
}

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = await prisma.shop.findUnique({ where: { shopDomain: session.shop } });
  if (!shop) throw new Error("Shop not found");

  const keys = await prisma.apiKey.findMany({
    where: { shopId: shop.id },
    orderBy: { createdAt: "desc" },
    take: 10,
  });

  return json({ keys });
}

export async function action({ request }: ActionFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = await prisma.shop.findUnique({ where: { shopDomain: session.shop } });
  if (!shop) throw new Error("Shop not found");

  const form = await request.formData();
  const name = String(form.get("name") ?? "API key");

  const token = `pp_${nanoid(24)}`;
  const tokenHash = sha256(token);

  await prisma.apiKey.create({
    data: { shopId: shop.id, name, tokenHash },
  });

  return json({ ok: true, token, message: "API key gemaakt (kopieer nu, wordt niet meer getoond)." });
}

export default function ApiKeys() {
  const { keys } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();

  return (
    <Page title="API Keys">
      <Layout>
        <Layout.Section>
          {actionData?.message ? (
            <Banner tone="success" title="Gelukt">
              <p>{actionData.message}</p>
            </Banner>
          ) : null}

          {actionData?.token ? (
            <Card>
              <BlockStack gap="200">
                <Text as="h2" variant="headingMd">Jouw token (éénmalig)</Text>
                <TextField label="Bearer token" value={actionData.token} readOnly autoComplete="off" />
                <Text as="p" tone="subdued">Gebruik in requests: Authorization: Bearer &lt;token&gt;</Text>
              </BlockStack>
            </Card>
          ) : null}

          <div style={{ height: 16 }} />

          <Card>
            <BlockStack gap="300">
              <Text as="h2" variant="headingMd">Nieuwe key</Text>
              <Form method="post">
                <BlockStack gap="300">
                  <TextField label="Naam" name="name" autoComplete="off" />
                  <Button submit variant="primary">Maak key</Button>
                </BlockStack>
              </Form>
            </BlockStack>
          </Card>

          <div style={{ height: 16 }} />

          <Card>
            <BlockStack gap="200">
              <Text as="h2" variant="headingMd">Laatste keys</Text>
              <ul>
                {keys.map((k) => (
                  <li key={k.id}>
                    <b>{k.name}</b> — created: {new Date(k.createdAt).toISOString()} — revoked: {k.revokedAt ? "ja" : "nee"}
                  </li>
                ))}
              </ul>
              <Text as="p" tone="subdued">Revoken is volgende upgrade (security bundle).</Text>
            </BlockStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
