import { type ActionFunctionArgs } from "@remix-run/node";
import { authenticate } from "~/shopify.server";
import { prisma } from "~/db.server";
import { computeProfit } from "~/lib/profit.server";
import { upsertShop } from "~/models/shop.server";

export async function action({ request }: ActionFunctionArgs) {
  const { topic, shop, payload } = await authenticate.webhook(request);

  await upsertShop(shop);
  const shopRow = await prisma.shop.findUnique({ where: { shopDomain: shop } });
  if (!shopRow) throw new Error("Shop not found");

  switch (topic) {
    case "ORDERS_CREATE":
    case "ORDERS_PAID":
      await handleOrderUpsert(shopRow.id, shop, payload);
      break;
    case "REFUNDS_CREATE":
      await handleRefund(shopRow.id, payload);
      break;
    case "APP_UNINSTALLED":
      await prisma.shop.delete({ where: { shopDomain: shop } }).catch(() => {});
      break;
    default:
      break;
  }

  return new Response("ok");
}

async function handleOrderUpsert(shopId: string, shopDomain: string, payload: any) {
  const shopRow = await prisma.shop.findUnique({ where: { shopDomain } });
  if (!shopRow) return;

  const shopifyOrderId = String(payload.id);
  const currency = String(payload.currency ?? shopRow.currency ?? "EUR");

  const createdAt = payload.created_at ? new Date(payload.created_at) : new Date();
  const processedAt = payload.processed_at ? new Date(payload.processed_at) : null;

  const subtotal = Number(payload.current_subtotal_price ?? payload.subtotal_price ?? 0);
  const shippingRevenue = Number(payload.total_shipping_price_set?.shop_money?.amount ?? payload.total_shipping_price ?? 0);
  const discounts = Number(payload.total_discounts ?? 0);
  const taxes = Number(payload.total_tax ?? 0);

  let cogsTotal = 0;
  const itemsData: any[] = [];

  for (const li of payload.line_items ?? []) {
    const shopifyProductId = String(li.product_id ?? "");
    const shopifyVariantId = String(li.variant_id ?? "");
    const sku = li.sku ? String(li.sku) : null;
    const productTitle = li.title ? String(li.title) : "Product";
    const variantTitle = li.variant_title ? String(li.variant_title) : null;

    const product = await prisma.product.upsert({
      where: { shopId_shopifyProductId: { shopId, shopifyProductId } },
      update: { title: productTitle },
      create: { shopId, shopifyProductId, title: productTitle },
    });

    const variant = shopifyVariantId
      ? await prisma.variant.upsert({
          where: { shopId_shopifyVariantId: { shopId, shopifyVariantId } },
          update: { sku, title: variantTitle, productId: product.id },
          create: { shopId, productId: product.id, shopifyVariantId, sku, title: variantTitle },
        })
      : null;

    const qty = Number(li.quantity ?? 0);
    const price = Number(li.price ?? 0);

    const unitCost = variant?.cost ?? 0;
    const cogs = unitCost * qty;
    cogsTotal += cogs;

    itemsData.push({
      shopId,
      shopifyLineItemId: String(li.id),
      quantity: qty,
      price,
      cogs,
      variantId: variant?.id ?? null,
    });
  }

  const shippingCost = shopRow.avgShippingCost ?? 0;
  const returnCost = 0;

  const { revenue, fees, profit, marginPct } = computeProfit({
    subtotal,
    shippingRevenue,
    discounts,
    taxes,
    refundedSubtotal: 0,
    refundedShipping: 0,
    refundedTaxes: 0,
    cogs: cogsTotal,
    paymentFeePct: shopRow.paymentFeePct ?? 0,
    paymentFeeFixed: shopRow.paymentFeeFixed ?? 0,
    shippingCost,
    returnCost,
  });

  const order = await prisma.order.upsert({
    where: { shopId_shopifyOrderId: { shopId, shopifyOrderId } },
    update: {
      createdAt,
      processedAt: processedAt ?? undefined,
      currency,
      subtotal,
      shippingRevenue,
      discounts,
      taxes,
      cogs: cogsTotal,
      fees,
      shippingCost,
      returnCost,
      revenue,
      profit,
      marginPct,
    },
    create: {
      shopId,
      shopifyOrderId,
      createdAt,
      processedAt: processedAt ?? undefined,
      currency,
      subtotal,
      shippingRevenue,
      discounts,
      taxes,
      cogs: cogsTotal,
      fees,
      shippingCost,
      returnCost,
      revenue,
      profit,
      marginPct,
    },
  });

  await prisma.orderItem.deleteMany({ where: { orderId: order.id } });
  if (itemsData.length) {
    await prisma.orderItem.createMany({
      data: itemsData.map((d) => ({ ...d, orderId: order.id })),
    });
  }
}

async function handleRefund(shopId: string, payload: any) {
  const shopifyOrderId = String(payload.order_id ?? payload.order?.id ?? "");
  if (!shopifyOrderId) return;

  const order = await prisma.order.findUnique({
    where: { shopId_shopifyOrderId: { shopId, shopifyOrderId } },
  });
  if (!order) return;

  let refundedSubtotal = 0;
  let refundedTaxes = 0;
  let refundedShipping = 0;

  for (const rli of payload.refund_line_items ?? []) {
    const li = rli.line_item;
    const qty = Number(rli.quantity ?? 0);
    const price = Number(li?.price ?? 0);
    refundedSubtotal += price * qty;

    for (const tax of li?.tax_lines ?? []) {
      refundedTaxes += Number(tax.price ?? 0);
    }
  }

  for (const sa of payload.shipping ?? []) {
    refundedShipping += Number(sa.amount ?? 0);
  }

  const shop = await prisma.shop.findUnique({ where: { id: shopId } });
  if (!shop) return;

  const returnCost = (payload.refund_line_items?.length ?? 0) > 0 ? (shop.avgReturnCost ?? 0) : 0;

  const { revenue, fees, profit, marginPct } = computeProfit({
    subtotal: order.subtotal,
    shippingRevenue: order.shippingRevenue,
    discounts: order.discounts,
    taxes: order.taxes,
    refundedSubtotal,
    refundedShipping,
    refundedTaxes,
    cogs: order.cogs,
    paymentFeePct: shop.paymentFeePct ?? 0,
    paymentFeeFixed: shop.paymentFeeFixed ?? 0,
    shippingCost: order.shippingCost,
    returnCost,
  });

  await prisma.order.update({
    where: { id: order.id },
    data: {
      refundedSubtotal,
      refundedShipping,
      refundedTaxes,
      returnCost,
      revenue,
      fees,
      profit,
      marginPct,
    },
  });
}
