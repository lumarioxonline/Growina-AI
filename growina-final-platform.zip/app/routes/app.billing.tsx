import { json, type ActionFunctionArgs, type LoaderFunctionArgs } from "@remix-run/node";
import { Form, useActionData, useLoaderData } from "@remix-run/react";
import { Page, Layout, Card, BlockStack, Text, Button, Banner, InlineStack } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { requestPlan } from "~/lib/billing.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session, billing } = await authenticate.admin(request);
  const check = process.env.BYPASS_BILLING === "true"
    ? { hasActivePayment: true }
    : await billing.check({ plans: ["STARTER","GROWTH","PRO"] });
  return json({ shop: session.shop, hasActivePayment: check.hasActivePayment });
}

export async function action({ request }: ActionFunctionArgs) {
  const form = await request.formData();
  const plan = String(form.get("plan") ?? "");
  if (!["STARTER","GROWTH","PRO"].includes(plan)) {
    return json({ ok: false, message: "Ongeldig plan." }, { status: 400 });
  }
  // Redirects to Shopify confirmation (never returns)
  return requestPlan(request, plan as any);
}

export default function Billing() {
  const { hasActivePayment } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();

  return (
    <Page title="Abonnement">
      <Layout>
        <Layout.Section>
          {hasActivePayment ? (
            <Banner tone="success" title="Actief abonnement">
              <p>Je hebt een actieve betaling. Je kunt terug naar de app.</p>
            </Banner>
          ) : (
            <Banner tone="warning" title="Kies een plan">
              <p>Growina werkt op abonnement. Kies een plan om door te gaan.</p>
            </Banner>
          )}

          {actionData?.message ? (
            <Banner tone="critical" title="Fout">
              <p>{actionData.message}</p>
            </Banner>
          ) : null}

          <Card>
            <BlockStack gap="300">
              <Text as="h2" variant="headingMd">Plannen</Text>

              <InlineStack gap="300" wrap>
                <PlanCard plan="STARTER" price="€19/maand" bullets={["Dashboard + products", "COGS import", "Basic alerts"]} />
                <PlanCard plan="GROWTH" price="€49/maand" bullets={["Alles van Starter", "Daily reports", "Webhook notificaties"]} />
                <PlanCard plan="PRO" price="€99/maand" bullets={["Alles van Growth", "Ad spend tracking", "Priority support"]} />
              </InlineStack>
            </BlockStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}

function PlanCard({ plan, price, bullets }: { plan: string; price: string; bullets: string[] }) {
  return (
    <Card>
      <BlockStack gap="200">
        <Text as="h3" variant="headingSm">{plan}</Text>
        <Text as="p"><b>{price}</b></Text>
        <ul>
          {bullets.map((b) => <li key={b}>{b}</li>)}
        </ul>
        <Form method="post">
          <input type="hidden" name="plan" value={plan} />
          <Button submit variant="primary">Kies {plan}</Button>
        </Form>
      </BlockStack>
    </Card>
  );
}
