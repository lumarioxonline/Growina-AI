import { json, type LoaderFunctionArgs } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { Page, Layout, Card, BlockStack, Text } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { prisma } from "~/db.server";
import { generateDecisions } from "~/lib/ai-decisions.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = await prisma.shop.findUnique({ where: { shopDomain: session.shop } });
  const decisions = await generateDecisions(shop!.id);
  return json({ decisions });
}

export default function Decisions() {
  const { decisions } = useLoaderData<typeof loader>();

  return (
    <Page title="AI Decisions">
      <Layout>
        <Layout.Section>
          <Card>
            <BlockStack gap="200">
              <Text as="h2" variant="headingMd">Aanbevelingen</Text>
              <ul>
                {decisions.map((d:string,i:number)=>(
                  <li key={i}>{d}</li>
                ))}
              </ul>
            </BlockStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
