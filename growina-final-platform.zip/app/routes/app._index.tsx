import { json, type LoaderFunctionArgs } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { Page, Layout, Card, Text, BlockStack } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { getOverview } from "~/models/orders.server";
import { formatMoney, formatPct } from "~/lib/format";
import { upsertShop } from "~/models/shop.server";
import { prisma } from "~/db.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;
  await upsertShop(shop);

  const shopRow = await prisma.shop.findUnique({ where: { shopDomain: shop } });
  const overview = await getOverview(shop, 30);

  return json({ shop, currency: shopRow?.currency ?? "EUR", overview });
}

export default function Index() {
  const { overview, currency } = useLoaderData<typeof loader>();

  return (
    <Page title="Dashboard">
      <Layout>
        <Layout.Section>
          <Card>
            <BlockStack gap="300">
              <Text as="h2" variant="headingMd">Laatste 30 dagen</Text>
              <Text as="p">Netto winst: <b>{formatMoney(overview.totalProfit, currency)}</b></Text>
              <Text as="p">Omzet: <b>{formatMoney(overview.totalRevenue, currency)}</b></Text>
              <Text as="p">Marge: <b>{formatPct(overview.marginPct)}</b></Text>
              <Text as="p" tone="subdued">
                Tip: voeg kostprijzen (COGS) toe voor alle SKU’s voor de meest accurate winst.
              </Text>
            </BlockStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
