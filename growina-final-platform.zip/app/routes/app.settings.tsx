import { json, type ActionFunctionArgs, type LoaderFunctionArgs } from "@remix-run/node";
import { Form, useActionData, useLoaderData } from "@remix-run/react";
import { Page, Layout, Card, BlockStack, InlineStack, TextField, Button, Banner, Text } from "@shopify/polaris";
import { authenticate } from "~/shopify.server";
import { getShopByDomain, upsertShop, updateShopSettings } from "~/models/shop.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shopDomain = session.shop;
  await upsertShop(shopDomain);
  const shop = await getShopByDomain(shopDomain);
  return json({ shop });
}

export async function action({ request }: ActionFunctionArgs) {
  const { session } = await authenticate.admin(request);
  const shopDomain = session.shop;

  const form = await request.formData();

  const paymentFeePct = Number(form.get("paymentFeePct") ?? 0) / 100;
  const paymentFeeFixed = Number(form.get("paymentFeeFixed") ?? 0);
  const avgShippingCost = Number(form.get("avgShippingCost") ?? 0);
  const avgReturnCost = Number(form.get("avgReturnCost") ?? 0);
  const currency = String(form.get("currency") ?? "EUR");
  const timezone = String(form.get("timezone") ?? "Europe/Amsterdam");

  if (![paymentFeePct, paymentFeeFixed, avgShippingCost, avgReturnCost].every((n) => Number.isFinite(n))) {
    return json({ ok: false, message: "Controleer je getallen." }, { status: 400 });
  }

  await updateShopSettings(shopDomain, {
    paymentFeePct,
    paymentFeeFixed,
    avgShippingCost,
    avgReturnCost,
    currency,
    timezone,
  });

  return json({ ok: true, message: "Instellingen opgeslagen." });
}

export default function Settings() {
  const { shop } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();

  const pct = ((shop?.paymentFeePct ?? 0) * 100).toFixed(2);

  return (
    <Page title="Instellingen">
      <Layout>
        <Layout.Section>
          {actionData?.message ? (
            <Banner tone={actionData.ok ? "success" : "critical"} title={actionData.ok ? "Gelukt" : "Fout"}>
              <p>{actionData.message}</p>
            </Banner>
          ) : null}

          <Card>
            <BlockStack gap="300">
              <Text as="h2" variant="headingMd">Winst aannames (MVP)</Text>
              <Text as="p" tone="subdued">
                Dit maakt Growina direct bruikbaar zonder extra integraties. Je kunt het later verfijnen.
              </Text>

              <Form method="post">
                <BlockStack gap="300">
                  <InlineStack gap="300" wrap>
                    <div style={{ minWidth: 260 }}>
                      <TextField label="Payment fee (%)" name="paymentFeePct" autoComplete="off" defaultValue={pct} />
                    </div>
                    <div style={{ minWidth: 260 }}>
                      <TextField label="Payment fee vast (per order)" name="paymentFeeFixed" autoComplete="off" defaultValue={(shop?.paymentFeeFixed ?? 0).toString()} />
                    </div>
                  </InlineStack>

                  <InlineStack gap="300" wrap>
                    <div style={{ minWidth: 260 }}>
                      <TextField label="Gemiddelde shipping cost (per order)" name="avgShippingCost" autoComplete="off" defaultValue={(shop?.avgShippingCost ?? 0).toString()} />
                    </div>
                    <div style={{ minWidth: 260 }}>
                      <TextField label="Gemiddelde return cost (per return)" name="avgReturnCost" autoComplete="off" defaultValue={(shop?.avgReturnCost ?? 0).toString()} />
                    </div>
                  </InlineStack>

                  <InlineStack gap="300" wrap>
                    <div style={{ minWidth: 260 }}>
                      <TextField label="Currency" name="currency" autoComplete="off" defaultValue={shop?.currency ?? "EUR"} />
                    </div>
                    <div style={{ minWidth: 260 }}>
                      <TextField label="Timezone" name="timezone" autoComplete="off" defaultValue={shop?.timezone ?? "Europe/Amsterdam"} />
                    </div>
                  </InlineStack>

                  <Button submit variant="primary">Opslaan</Button>
                </BlockStack>
              </Form>
            </BlockStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
