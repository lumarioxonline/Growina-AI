import { prisma } from "~/db.server";

export async function upsertShop(shopDomain: string) {
  return prisma.shop.upsert({
    where: { shopDomain },
    update: {},
    create: { shopDomain },
  });
}

export async function getShopByDomain(shopDomain: string) {
  return prisma.shop.findUnique({ where: { shopDomain } });
}

export async function updateShopSettings(shopDomain: string, data: {
  paymentFeePct?: number;
  paymentFeeFixed?: number;
  avgShippingCost?: number;
  avgReturnCost?: number;
  currency?: string;
  timezone?: string;
}) {
  return prisma.shop.update({
    where: { shopDomain },
    data,
  });
}
