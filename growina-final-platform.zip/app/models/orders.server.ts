import { prisma } from "~/db.server";

export async function getOverview(shopDomain: string, days = 30) {
  const shop = await prisma.shop.findUnique({ where: { shopDomain } });
  if (!shop) throw new Error("Shop not found");

  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

  const orders = await prisma.order.findMany({
    where: { shopId: shop.id, createdAt: { gte: since } },
    select: { revenue: true, profit: true, marginPct: true, createdAt: true },
    orderBy: { createdAt: "asc" },
  });

  const totalRevenue = orders.reduce((a, o) => a + o.revenue, 0);
  const totalProfit = orders.reduce((a, o) => a + o.profit, 0);
  const marginPct = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0;

  return { totalRevenue, totalProfit, marginPct, orders };
}

export async function getProductProfitTable(shopDomain: string, days = 30, take = 100) {
  const shop = await prisma.shop.findUnique({ where: { shopDomain } });
  if (!shop) throw new Error("Shop not found");

  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

  const items = await prisma.orderItem.findMany({
    where: { shopId: shop.id, order: { createdAt: { gte: since } } },
    include: { variant: { include: { product: true } }, order: true },
    take: 10000,
  });

  const map = new Map<string, any>();
  for (const it of items) {
    const pTitle = it.variant?.product?.title ?? "Unknown product";
    const sku = it.variant?.sku ?? "—";
    const key = `${pTitle}__${sku}`;
    const revenue = it.price * it.quantity;
    const cogs = it.cogs;
    const cur = map.get(key) ?? { product: pTitle, sku, revenue: 0, cogs: 0, qty: 0, orders: new Set<string>() };
    cur.revenue += revenue;
    cur.cogs += cogs;
    cur.qty += it.quantity;
    cur.orders.add(it.orderId);
    map.set(key, cur);
  }

  const rows = Array.from(map.values()).map((r) => {
    const profit = r.revenue - r.cogs;
    const marginPct = r.revenue > 0 ? (profit / r.revenue) * 100 : 0;
    return { product: r.product, sku: r.sku, revenue: r.revenue, profit, marginPct, qty: r.qty, orders: r.orders.size };
  });

  rows.sort((a, b) => b.profit - a.profit);
  return rows.slice(0, take);
}
