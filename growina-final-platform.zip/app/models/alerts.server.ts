import { prisma } from "~/db.server";

export async function listAlertRules(shopDomain: string) {
  const shop = await prisma.shop.findUnique({ where: { shopDomain } });
  if (!shop) throw new Error("Shop not found");

  return prisma.alertRule.findMany({
    where: { shopId: shop.id },
    orderBy: { createdAt: "desc" },
  });
}

export async function upsertAlertRule(shopDomain: string, rule: { type: string; threshold?: number | null; isActive?: boolean }) {
  const shop = await prisma.shop.findUnique({ where: { shopDomain } });
  if (!shop) throw new Error("Shop not found");

  return prisma.alertRule.upsert({
    where: { shopId_type: { shopId: shop.id, type: rule.type } },
    update: { threshold: rule.threshold ?? undefined, isActive: rule.isActive ?? undefined },
    create: { shopId: shop.id, type: rule.type, threshold: rule.threshold ?? null, isActive: rule.isActive ?? True },
  });
}

export async function deleteAlertRule(shopDomain: string, type: string) {
  const shop = await prisma.shop.findUnique({ where: { shopDomain } });
  if (!shop) throw new Error("Shop not found");

  await prisma.alertRule.delete({
    where: { shopId_type: { shopId: shop.id, type } },
  });
}
