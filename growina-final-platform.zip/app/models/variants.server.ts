import { prisma } from "~/db.server";

export async function bulkUpsertVariantCostsFromSku(params: {
  shopDomain: string;
  rows: Array<{ sku: string; cost: number }>;
}) {
  const shop = await prisma.shop.findUnique({ where: { shopDomain: params.shopDomain } });
  if (!shop) throw new Error("Shop not found");

  const results: Array<{ sku: string; updated: number }> = [];
  for (const row of params.rows) {
    const r = await prisma.variant.updateMany({
      where: { shopId: shop.id, sku: row.sku },
      data: { cost: row.cost, costValidFrom: new Date() },
    });
    results.push({ sku: row.sku, updated: r.count });
  }
  return results;
}

export async function listVariantsMissingCogs(shopDomain: string, take = 50) {
  const shop = await prisma.shop.findUnique({ where: { shopDomain } });
  if (!shop) throw new Error("Shop not found");

  return prisma.variant.findMany({
    where: { shopId: shop.id, OR: [{ cost: null }] },
    take,
    orderBy: { sku: "asc" },
    include: { product: true },
  });
}
