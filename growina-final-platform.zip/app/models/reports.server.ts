import { prisma } from "~/db.server";

export async function computeAndStoreDailyReport(shopDomain: string, dateISO: string) {
  const shop = await prisma.shop.findUnique({ where: { shopDomain } });
  if (!shop) throw new Error("Shop not found");

  const dayStart = new Date(dateISO + "T00:00:00.000Z");
  const dayEnd = new Date(dayStart.getTime() + 24 * 60 * 60 * 1000);

  const orders = await prisma.order.findMany({
    where: { shopId: shop.id, createdAt: { gte: dayStart, lt: dayEnd } },
    select: { revenue: true, profit: true },
  });

  const revenue = orders.reduce((a, o) => a + o.revenue, 0);
  const profitBeforeAds = orders.reduce((a, o) => a + o.profit, 0);

  const adRows = await prisma.adSpendDaily.findMany({
    where: { shopId: shop.id, date: { gte: dayStart, lt: dayEnd } },
    select: { spend: true },
  });
  const adSpend = adRows.reduce((a, r) => a + r.spend, 0);

  const profit = profitBeforeAds - adSpend;
  const marginPct = revenue > 0 ? (profit / revenue) * 100 : 0;

  const report = await prisma.dailyReport.upsert({
    where: { shopId_date: { shopId: shop.id, date: dayStart } },
    update: { revenue, profit, marginPct },
    create: { shopId: shop.id, date: dayStart, revenue, profit, marginPct },
  });

  return { shop, report, adSpend, profitBeforeAds };
}

export async function listDailyReports(shopDomain: string, take = 30) {
  const shop = await prisma.shop.findUnique({ where: { shopDomain } });
  if (!shop) throw new Error("Shop not found");

  return prisma.dailyReport.findMany({
    where: { shopId: shop.id },
    orderBy: { date: "desc" },
    take,
  });
}
