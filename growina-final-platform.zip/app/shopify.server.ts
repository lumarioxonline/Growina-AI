import { PrismaSessionStorage } from "@shopify/shopify-app-session-storage-prisma";
import { shopifyApp } from "@shopify/shopify-app-remix/server";
import { LATEST_API_VERSION, BillingInterval } from "@shopify/shopify-api";
import { prisma } from "~/db.server";

const apiKey = process.env.SHOPIFY_API_KEY!;
const apiSecret = process.env.SHOPIFY_API_SECRET!;
const appUrl = process.env.SHOPIFY_APP_URL!;
const scopes = (process.env.SCOPES ?? "read_orders,read_products").split(",");

export const shopify = shopifyApp({
  apiKey,
  apiSecretKey: apiSecret,
  apiVersion: LATEST_API_VERSION,
  appUrl,
  scopes,
  sessionStorage: new PrismaSessionStorage(prisma),

  // Billing plans (works with Billing API; if you use Managed App Pricing, keep this but rely on Partner pricing)
  billing: {
    STARTER: {
      lineItems: [
        { amount: 19, currencyCode: "EUR", interval: BillingInterval.Every30Days },
      ],
      trialDays: 7,
    },
    GROWTH: {
      lineItems: [
        { amount: 49, currencyCode: "EUR", interval: BillingInterval.Every30Days },
      ],
      trialDays: 7,
    },
    PRO: {
      lineItems: [
        { amount: 99, currencyCode: "EUR", interval: BillingInterval.Every30Days },
      ],
      trialDays: 7,
    },
  },

  webhooks: {
    ORDERS_CREATE: { deliveryMethod: "http", callbackUrl: "/webhooks" },
    ORDERS_PAID: { deliveryMethod: "http", callbackUrl: "/webhooks" },
    REFUNDS_CREATE: { deliveryMethod: "http", callbackUrl: "/webhooks" },
    APP_UNINSTALLED: { deliveryMethod: "http", callbackUrl: "/webhooks" },
  },

  hooks: {
    afterAuth: async ({ session }) => {
      await shopify.registerWebhooks({ session });
    },
  },
});

export const authenticate = shopify.authenticate;
